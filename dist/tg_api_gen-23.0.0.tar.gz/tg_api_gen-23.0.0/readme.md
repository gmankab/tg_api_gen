# tg_api_gen

lightweight skript that generates realistic device_model, app_verion, system_version for telegram

thanks [opentele](https://github.com/thedemons/opentele)

